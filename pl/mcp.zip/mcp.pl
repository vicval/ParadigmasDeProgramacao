move_dir([MD,CD],[ME,CE],N,M,Max, Str):-
	MD1 is MD-N,
	ME1 is ME+N,
	CD1 is CD-M,
	CE1 is CE+M,
	write('Margem direita:'),exibe([MD1,CD1]),
	write('Margem esquerda:'),exibe([ME1,CE1]), nl,
	verifica_estado_final([MD1,CD1],[ME1,CE1],Max),
	estados_esq([ME1,CE1],[MD1,CD1],Max,Str).

move_esq([MD,CD],[ME,CE],N,M,Max, Str):-
	MD1 is MD+N,
	ME1 is ME-N,
	CD1 is CD+M,
	CE1 is CE-M,
	write('Margem direita:'),exibe([MD1,CD1]),
	write('Margem esquerda:'),exibe([ME1,CE1]), nl,
	verifica_estado_final([MD1,CD1],[ME1,CE1],Max),
	estados_dir([ME1,CE1],[MD1,CD1],Max, Str).

verifica_move_dir([MD,CD],[ME,CE]):-
	MD >= 0, 
	CD >= 0,
	MD >= CD,
	ME >= CE.
	
verifica_move_esq([MD,CD],[ME,CE]):-
	ME >= 0, 
	CE >= 0,
	MD >= CD,
	ME >= CE.

exibe([]) :- nl.
exibe([X|Y]) :- write(X) , exibe(Y).

estados_esq([ME,CE],[MD,CD], Max, Str):-
	read(Str,N1),read(Str,M1),
	N is N1, M is M1,
	move_esq([MD,CD],[ME,CE],N,M,Max, Str),
	verifica_move_esq([MD,CD],[ME,CE],N,M, Max).

estados_dir([ME,CE],[MD,CD], Max, Str):-
	read(Str,N1),read(Str,M1),
	N is N1, M is M1,
	move_dir([MD,CD],[ME,CE],N,M,Max, Str),
	verifica_move_dir([MD,CD],[ME,CE],N,M, Max).

verifica_estado_final([MD,CD],[ME,CE],Max):-
	Z is Max + 1,
	(CE == 0 , ME == 0 , MD == Z , CD == Z) ->
    	write('Chegou no estado final!'), nl ; nl.

inicio:-
	open('moves.txt',read,Str),
	read(Str,Max), write(Max), nl, Z is Max-1,
	write('Estado inicial:'), nl,
	write('Margem direita:'),exibe([Max,Max]),
	write('Margem esquerda:'),exibe([0,0]), nl,
	estados_esq([Max,Max],[0,0], Z, Str).